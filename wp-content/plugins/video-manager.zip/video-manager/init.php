<?php 
/*
Plugin Name: Video Manager
Author: Ian Tumulak
Version: v1.0
*/


/* GLOBAL VARIABLES */
$folder_name = WP_PLUGIN_DIR . '/video-manager'; // Rename the path per versioning
$url_path = plugins_url('', __FILE__);


/* DEFINE FILE DIRECTORIES */
define('ION_ADMIN', $folder_name . '/admin/');
define('ION_DISPLAY', $folder_name. '/display/');
define('ION_MODKORE', $folder_name. '/modkore/');
define('ION_DIR', $folder_name);

/* LOAD DATABASE */
class DB_install {
	var $dbversion   = '1.0.0';
	
	function DB_install() {
		register_activation_hook(__FILE__, array(&$this, 'activate') );
		register_deactivation_hook(__FILE__, array(&$this, 'deactivate_options') );
	}
	
	function activate() {
		
		if (version_compare(PHP_VERSION, '5.2.0', '<')) { 
				deactivate_plugins(plugin_basename(__FILE__)); // Deactivate ourself
                wp_die("Sorry, but you can't run this plugin, it requires PHP 5.2 or higher."); 
				return; 
        }
		
		$this->install_tables();
	}
	
	function install_tables() {
		global $wpdb;
		
		// upgrade function changed in WordPress 2.3	
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		
		$v_directory_ = $wpdb->prefix . "video_directory";
		$v_listings_ = $wpdb->prefix . "video_list";

		if( !$wpdb->get_var( "SHOW TABLES LIKE '$v_listings_'" ) ) { // Veriry if table exist
			$sql = "CREATE TABLE ".$v_listings_." (
					ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,							   
					dir_id INT NOT NULL ,
					video_name VARCHAR( 1000 ) NOT NULL ,
					embed_value TEXT NULL ,
					options TEXT NOT NULL,
					INDEX ( dir_id )
					)";
			dbDelta($sql);	
		}
		
		if( !$wpdb->get_var( "SHOW TABLES LIKE '$v_directory_'" ) ) { // Veriry if table exist
			$sql = "CREATE TABLE ".$v_directory_." (
					id INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
					directory_name VARCHAR( 1000 ) NOT NULL ,
					video_count INT NOT NULL ,
					date_created DATE DEFAULT '0000-00-00' NOT NULL ,
					video_order TINYTEXT NOT NULL
					)";
			dbDelta($sql);	
		}
		
		if( $wpdb->get_var( "SHOW TABLES LIKE '$v_directory_'" ) && $wpdb->get_var( "SHOW TABLES LIKE '$v_listings_'" ) ) {
			add_option("ion_dbversion", $this->dbversion);
			add_option("v_directory_", $v_directory_);
			add_option("v_listings_", $v_listings_);
		}
	}
	
	function deactivate_options() {
		delete_option("ion_dbversion");
		delete_option("v_directory_");
		delete_option("v_listings_");
	}
}

$db_install = &new DB_install();

/* LOAD ADMIN */
include_once(ION_ADMIN . '/page-templates.php');
include_once(ION_ADMIN . '/page.php');
include_once(ION_ADMIN . '/tinymce/tinymce.php');

/* LOAD DISPLAY */
include_once(ION_DISPLAY . 'loader.php');
include_once(ION_DISPLAY . 'video-directory.php');

/* LOAD MODKORE */
include_once(ION_MODKORE . 'shortcodes.php');
include_once(ION_MODKORE . 'authenticate_user.php');
include_once(ION_MODKORE . 'chargify.php');

?>