<?php
/**
 * Class template to display the video directory
 * @since 1.0.0
 */

class IonVideoDirectoryDisplay {
	function show_directory($v_id) {
		global $wpdb;
		
		$table1 = get_option('v_listings_');
		$table2 = get_option('v_directory_');
		$def_option = get_option('ion_video_options');
?>
		<div class="wrap">
<?php
		$v_id = explode( ',', $v_id );
		
		
		
		foreach($v_id as $v) {
		
		$show_ = $wpdb->get_results("SELECT directory_name, video_order, video_count FROM $table2 WHERE id IN (".$v.")");
		
		foreach($show_ as $chapter) {
//			echo $chapter->video_count; die;
			if($chapter->video_count > 0) :
			
			$c_order = unserialize($chapter->video_order);
			$j_order = $c_order;
			$c = implode(',',$c_order);
			$show_options = $wpdb->get_results("SELECT * FROM $table1 WHERE id IN (".$c.")", ARRAY_A);

			/**
			 * Calculate the total duration for one directory
			 * @since 1.0.0
			 * @source http://stackoverflow.com/questions/3172332/convert-seconds-to-hourminutesecond#answer-3172368
			 */
			 
			 $total_duration = '';
			
			foreach($show_options as $x) {
				$show = unserialize($x['options']);
				$show = $show[0];

				$total_duration += floor($show['duration']['hours'] * 3600) + floor($show['duration']['minutes'] * 60) + floor($show['duration']['seconds']);
			}
			
			$hours = floor($total_duration / 3600);
			$minutes = floor(($total_duration / 60) % 60);
			$seconds = $total_duration % 60;
			
			/**
			 * Ends here.
			 */
?>
		<div class="postbox">
        	<h3 class="directory-name"><span><?php echo stripslashes( $chapter->directory_name ); ?></span><?php if ($def_option['show_duration'] == 1) : ?><span style="float:right;"><?php echo $hours  . 'hr ' . str_pad($minutes, 2, 0, STR_PAD_LEFT) . 'm ' . str_pad($seconds, 2, 0, STR_PAD_LEFT) . 's'; ?></span><?php endif; ?></h3>
            <div class="inside">
            	<ul class="video-list">
				<?php 
					if($chapter->video_count > 0) :						
						foreach($show_options as $j) {
							$list = $wpdb->get_results("SELECT * FROM $table1 WHERE ID = '$j_order[0]'", ARRAY_A);
							array_shift($j_order);
							$list = $list[0];
				?>		
                		<li>
				<?php 
						global $ion_auth_users;	
						$o = unserialize($list['options']);
						$o = $o[0];
						if( $ion_auth_users->all($o['options']) ) {
				?>
                		<a class="<?php echo (!empty($o['media_id']) ? 'show_jw_player' : 'show_iframe'); ?>" href="#<?php echo sanitize_title( $list['video_name']); ?>-<?php echo $list['ID']; ?><?php echo (!empty($o['media_id']) ? '_wrapper' : ''); ?>" title="<?php echo sanitize_title( $list['video_name']); ?>-<?php echo $list['ID']; ?>"><?php echo stripslashes( $list['video_name'] ); ?></a><?php if ($def_option['show_duration'] == 1) : ?><span class="video-duration"><?php if ( $o['duration']['hours'] !== '000' ) : echo abs($o['duration']['hours']); ?>hr<?php endif; ?> <?php echo $o['duration']['minutes']; ?>m <?php echo $o['duration']['seconds']; ?>s</span><?php endif; ?>
                <?php 
						} else {
				?>
                		<a class="login-pop noaccess" href="#no-access"><?php echo $list['video_name']; ?></a><?php if ($def_option['show_duration'] == 1) : ?><span class="video-duration"><?php if ( $o['duration']['hours'] !== '000' ) : echo abs($list['duration']['hours']); ?>hr<?php endif; ?> <?php echo $o['duration']['minutes']; ?>m <?php echo $o['duration']['seconds']; ?>s</span><?php endif; ?>
                <?php 
						}
				?>
                        </li>
				<?php
						}
					endif;
				?>
                </ul><!-- .video-list -->                
                <div class="iframe">
                	<?php 
					if($chapter->video_count > 0) :
						foreach($show_options as $list) {
							$o = unserialize($list['options']);
							$o = $o[0];
					?>
                    	<div id="<?php echo sanitize_title( $list['video_name']); ?>-<?php echo $list['ID']; ?>" class="ion-css">
							<?php 
							if( empty($o['media_id']) ) : 
								echo stripslashes(html_entity_decode(( $list['embed_value'] ))); 
							else :
								$video =  wp_get_attachment_url( $o['media_id'] );
							?>
								<script type="text/javascript">
                                    jwplayer("<?php echo sanitize_title( $list['video_name']); ?>-<?php echo $list['ID']; ?>").setup({
                                        flashplayer: "<?php echo $GLOBALS['url_path'] . '/display/mediaplayer-5.8/'; ?>player.swf",
										width: <?php echo $o['width']; ?>,
										height: <?php echo $o['height']; ?>,
                                        file: "<?php echo $video; ?>"
                                    });
                                </script>                                
                            <?php
							endif;
							?>
                        </div>
                    <?php 
						}
					endif;
					?>
                </div>
            </div><!-- .inside -->
		</div><!-- .postbox -->
<?php
		else : 
?>
		<div class="postbox">
        	<h3 class="directory-name"><span><?php echo stripslashes( $chapter->directory_name ); ?></span></h3>
            <div class="inside">
            	<ul class="video-list">
                	<li>No videos available.</li>
                </ul>
			</div>
		</div><!-- empty .postbox -->
<?php
		endif; 
		} }
?>
		</div><!-- .wrap -->	
<?php
	}

	function container_tabs( $list_header = array(), $content_list = array() ) {
		$i = 0; $j = 0;
?>
	<div class="ion_tabs">
		<ul>
			<?php foreach($list_header as $list) { ?>
				<li><a href="#tabs-<?php echo $i++; ?>"><?php echo $list; ?></a></li>
			<?php } ?>
		</ul>
	<?php foreach($content_list as $container) { ?>
    	<div id="tabs-<?php echo $j++; ?>"><?php echo do_shortcode( $container ); ?><br class="clear" /></div>        	
	<?php } ?>    
    
    </div>
    
<?php
	}
	
	function container_tabs_( $list_header = array(), $content_list = '' ) {
?>	
		<div class="ion_tabs">
		<ul>	
		<?php foreach($list_header as $id => $name) {?>
        	<li><a href="#<?php echo $id; ?>"><?php echo $name; ?></a></li>
		<?php } ?>
        </ul>
<?php
		echo do_shortcode( $content_list );
?>
		</div>
<?php		
	}
	
	function tabs($d = array(), $content = '') {
?>
		<div id="<?php echo $d['id']; ?>"><?php echo do_shortcode( $content ); ?><br class="clear" /></div>
<?php
	}
}

//$ion_video_directory_display = &new IonVideoDirectoryDisplay();
?>