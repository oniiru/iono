// JavaScript Document

jQuery(document).ready( function() {
	jQuery('.postbox h3.directory-name').click( function() {
        jQuery(jQuery(this).parent().get(0)).toggleClass('closed');
    });
	
	jQuery('.show_iframe').click( function() {
		var href = jQuery(this).attr('href');
		var get_width = jQuery(href + ' iframe').attr('width');
		var get_title = jQuery(this).text();
 
		jQuery(href).dialog({
			modal: true,
			resizable: false,
			draggable: false,
			width: get_width ,
			title: get_title,
			create: function(event, ui){
				jQuery('.ui-dialog').wrap('<div class="ion-css" />');
			},
			open: function(event, ui){
				jQuery('.ui-widget-overlay').wrap('<div class="ion-css" />');
			},
			close: function(event, ui){
				jQuery(".ion-css").filter(function(){
					if (jQuery(this).text() == "")
					{
						return true;
					}
					return false;
				}).remove();
				jQuery( this ).dialog( "destroy" ); 
			}	
		});
		
		return false;
	});
	
	jQuery('.show_jw_player').click( function() {
		var this_id =jQuery(this).attr('title');
		var href = jQuery(this).attr('href');
		var get_width = jQuery(href).width();
		var get_height = jQuery(href).height();
		var get_title = jQuery(this).text();
		var this_html = jQuery(href).html();
 
		jQuery(href).dialog({
			modal: true,
			resizable: false,
			draggable: false,
			width: get_width,
			height: get_height,
			title: get_title,
			create: function(event, ui){
				jQuery('.ui-dialog').wrap('<div class="ion-css" />');
			},
			open: function(event, ui){
				jQuery('.ui-widget-overlay').wrap('<div class="ion-css" />');
			},
			close: function(event, ui){
				jQuery(".ion-css").filter(function(){
					if (jQuery(this).text() == "")
					{
						return true;
					}
					return false;
				}).remove();
				
				jQuery( '.iframe' ).prepend('<div id="'+this_id+'_wrapper" style="position: relative; width: '+get_width+'px; height: '+get_height+'px;">'+this_html+'</div>' ); 
				jQuery( href ).dialog( "destroy" ); 
			}	
		});
		
		return false;
	});
	
	jQuery( ".ion_tabs" ).tabs({
		create: function(event, ui){
			jQuery(this).wrap('<div class="ion-css" />');
		}
	});
	
	//jQuery( "#dialog:ui-dialog" ).dialog( "destroy" );
	
	jQuery("#update-0").fancybox({
		'titlePosition'		: 'inside',
		'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'overlayColor'		: '#000',
		'overlayOpacity'	: 0.5
	});
});