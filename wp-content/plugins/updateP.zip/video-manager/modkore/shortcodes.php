<?php
/**
 * Use of WordPress Shortcode API for more features
 * @since 1.0.0
 */


class IonShortcodes extends IonVideoDirectoryDisplay {
	
	var $tablist = array();
	var $tabcontent = array();
	
	function IonShortcodes() {
		add_shortcode( 'videodirectory', array(&$this, 'get_directory' ) );
		//add_shortcode( 'ion_tabset', array(&$this, 'create_tabs' ) );
		add_shortcode( 'ion_tabset', array(&$this, 'create_tabs_' ) );
		//add_shortcode( 'ion_tab', array(&$this, 'single_tabs' ) );
		add_shortcode( 'ion_tab', array(&$this, 'single_tabs_' ) );
	}
	
	function get_directory( $atts, $content = null ) {
		extract( shortcode_atts( array( 'id' => ''), $atts ) );
		
		return $this->show_directory($id);
	}
	
	function create_tabs() {
		return $this->container_tabs( $this->tablist, $this->tabcontent );
	}
	
	function single_tabs( $atts, $content = null ) {
		extract( shortcode_atts( array( 'title' => ''), $atts ) );
	
		array_push( $this->tablist, $title );
		array_push( $this->tabcontent, $content );
	}
	
	function create_tabs_($atts, $content = null) {
		extract( shortcode_atts( array( 'title' => ''), $atts ) );

		return $this->container_tabs_( $atts, $content );
	}
	
	function single_tabs_( $atts, $content ) {
		extract( shortcode_atts( array( 'title' => ''), $atts ) );
		
		return $this->tabs( $atts, $content );
	}
	
	function verify_chargify_users() {
	}	
}

$ion_shorcodes = &new IonShortcodes();
?>