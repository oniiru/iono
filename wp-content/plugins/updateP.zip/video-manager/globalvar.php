<?php

/*
 * Global variables
*/

global $wpdb;

$v_directory = $wpdb->prefix . "video_name_directory";
$v_listings = $wpdb->prefix . "video_listings";


?>