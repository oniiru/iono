<?php

require_once('../../../../../wp-load.php');

if ( !is_user_logged_in() || !current_user_can('edit_posts') )
    die('You are not allowed to call this page directly.');
    
global $wpdb;

@header('Content-Type: ' . get_option('html_type') . '; charset=' . get_option('blog_charset'));
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Video Directory</title>
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php echo get_option('blog_charset'); ?>" />
	<script language="javascript" type="text/javascript" src="<?php echo get_bloginfo('wpurl'); ?>/wp-includes/js/tinymce/tiny_mce_popup.js"></script>
	<script language="javascript" type="text/javascript" src="<?php echo get_bloginfo('wpurl'); ?>/wp-includes/js/tinymce/utils/mctabs.js"></script>
	<script language="javascript" type="text/javascript" src="<?php echo get_bloginfo('wpurl'); ?>/wp-includes/js/tinymce/utils/form_utils.js"></script>
	<script language="javascript" type="text/javascript" src="<?php echo get_bloginfo('wpurl'); ?>/wp-includes/js/jquery/jquery.js"></script>
    <script language="javascript" type="text/javascript">
		function init() {
			tinyMCEPopup.resizeToInnerSize();
		}
		
		/*
			Source: http://stackoverflow.com/questions/1295950/javascript-to-select-multiple-options#answer-2070421
		*/
		
		function insertVideo() {
			var insert = '';
			var selectedArray = new Array();
			var selObj = document.getElementById('added-video-directory-list');
			var i;
			var count = 0;
			for (i=0; i<selObj.options.length; i++) {
				if (selObj.options[i].selected) {
				  selectedArray[count] = selObj.options[i].value;
				  count++;
				}
			}
			
			//alert(jQuery('#video-directory-list').attr('name'));
			if(selectedArray.length > 0) { // Check if array is not empty
				//alert(selectedArray);
				insert += '[videodirectory id="';
				insert += selectedArray;
				insert += '"]';
				returnToTinyMCE(insert);
			}
		}
		
		/*
			Transfer multiple selected option to another selection box
			Source: http://blog.jeremymartin.name/2008/02/easy-multi-select-transfer-with-jquery.html
		*/
		
		function transferSelect(from,to) {
			jQuery('#'+from+' option:selected').appendTo('#'+to); 
		}
		
		/*
			Copy multiple selected option to another selection box
			Source: http://stackoverflow.com/questions/4433861/copy-option-list-from-dropdownlist-jquery
		*/
		function cloneSelect(from,to) {
			jQuery('#'+from+' option:selected').clone().appendTo('#'+to); 
		}
		
		function removeSelect(option) {
			jQuery('#'+option+' option:selected').remove(); 
		}
		
		function insertSelected(id) {
			var insert = '';
			var selectedArray = new Array();
			var count = 0;
			
			jQuery('#'+id+' option').each(function() {
				selectedArray[count] = jQuery(this).val();
				count++;
			});
			
			if(selectedArray.length > 0) { // Check if array is not empty
				insert += '[videodirectory id=\"';
				insert += selectedArray;
				insert += '\"]';
				returnToTinyMCE(insert);
			}
		}
		
		function moveUpItem(id){
			jQuery('#'+id+' option:selected').each(function(){
				jQuery(this).insertBefore(jQuery(this).prev());
			});
		}
		
		function moveDownItem(id){
  			jQuery('#'+id+' option:selected').each(function(){
  		 		jQuery(this).insertAfter(jQuery(this).next());
			});
		}
		
		function insertTabs() {
			var insert = '[ion_tabset tab1=\"Title 1\" tab2=\"Title 2\" tab3=\"Title 3\"]<br /><br />[ion_tab id="tab1"]Content #1[/ion_tab]<br /><br />[ion_tab id="tab2"]Content #2[/ion_tab]<br /><br />[ion_tab id="tab3"]Content #3[/ion_tab]<br /><br />[/ion_tabset]';	
			returnToTinyMCE(insert);
		}
		
		function returnToTinyMCE(insertValue){
			if(window.tinyMCE) {
				window.tinyMCE.execInstanceCommand('content', 'mceInsertContent', false, insertValue);
				tinyMCEPopup.editor.execCommand('mceRepaint');
				tinyMCEPopup.close();
			}
			return;
		}
	</script>
    <base target="_self" />
</head>
<body id="link" onLoad="tinyMCEPopup.executeOnLoad('init();');">
<form name="video-directory-picker" action="#">
	<div style="width: 90%; margin: 0 auto 10px; border-bottom: 1px solid  #999; padding-bottom: 10px;">
    <h4>Pick video directory</h4>
    <p style="font-size: 10px;"><em>Note: you can pick multiple directory. (Ctrl/Shift + select an item)</em></p>
    
		<?php $v_directory = get_option('v_directory_'); if( $directories = $wpdb->get_results("SELECT * FROM ".$v_directory." ORDER BY id ASC") ) : ?>
        <table>
          <tr>
            <td>
                <select id="video-directory-list" size="10" multiple="multiple" id="video-directory-list" style="width: 180px;">
                  <?php foreach($directories as $list) {?>
                  <option value="<?php echo $list->id; ?>"><?php echo $list->directory_name ?></option>
                  <?php } ?>
                </select>
            </td>
            <td style="text-align: center;">
            	<input id="add_dir" style="margin: 0 auto;" class="mceButton" type="button" value="Add >>" onClick="cloneSelect('video-directory-list','added-video-directory-list');">
                <input id="remove_dir" style="margin: 0 auto;" class="mceButton" type="button" value="<< Remove" onClick="removeSelect('added-video-directory-list');">
            </td>
            <td>
				<select id="added-video-directory-list" name="added-video-directory-list[]" size="10" multiple="multiple" style="width: 180px;">
                </select>
            </td>
            <td style="text-align:center;">
            	<input type="button" class="mceButton" value="Up" onClick="moveUpItem('added-video-directory-list');">
                <input type="button" class="mceButton" value="Down" onClick="moveDownItem('added-video-directory-list');">
            </td>
          </tr>
        </table>
            
        <?php endif; ?>
        <div>&nbsp;</div>
        <div style="float:right"><input class="mceButton" value="Insert" type="button" onClick="insertSelected('added-video-directory-list');"></div>	
        <div style="float:left"><input class="mceButton" value="Cancel" type="button" onClick="tinyMCEPopup.close();"></div>
    	<br clear="all" />
    </div><!-- Video Directory Container -->
    <div style="width: 90%; margin: 0 auto 10px; border-bottom: 1px solid  #999; padding-bottom: 10px;">
     <h4>Miscellaneous</h4>
     <div>&nbsp;</div>
     <div style="float:left; margin: 0 3px;"><input class="mceButton" value="Create Tabs" type="button" onClick="insertTabs();"></div>     
     <br clear="all" />
    </div><!-- Miscellaneous functions -->
</form>
</body>
</html>