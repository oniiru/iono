<?php
/*Template Name: Signup Template*/
?>
<?php get_header(); ?>
</div><!-- header-area --></div><!-- end rays --></div><!-- end header-holder --></div><!-- end header -->
<?php truethemes_before_main_hook();// action hook, see truethemes_framework/global/hooks.php ?><div id="main"><?php get_template_part('theme-template-part-tools','childtheme'); ?><div class="main-holder"><div id="content" class="content_full_width"><div class="boxes"><h2>7 Day Trial, 30 day Moneyback Guarantee.<br></br> Get Started Today!</h2><div class="blocks"><?php $subacess=get_option('chargify');
$anual=$subacess["annualplan"];
$month=$subacess["monthlyplan"];
$products = ion_chargify::products();
foreach($products as $pro)
if($pro->id==$month)
$p1=$pro;
if($pro->id==$anual)
$p2=$pro;print_r($subacess["annualplan"]);
?><script type="text/javascript">function submitplan(id){switch(id){case 1:  document.monthlyform.submit();  break; case 2:  document.annualform.submit();  break; }}</script><div id="bl1" class="bbs">	
<form name="monthlyform" action="<?php print $subacess["signuppageurl"]; ?>" method="post">	
	
<p><a class="choosebnt" href="javascript:submitplan(1);" title="">Choose plan</a>		
<input type="hidden" name="monthlyoption" value="<?php print $subacess["monthlyplan"]; ?>"/>			
</form>	
</div>	
<div id="bl2" class="bbs">	<form name="annualform" action="<?php print $subacess["signuppageurl"]; ?>" method="post">			

<p><a class="choosebnt1" href="javascript:submitplan(2);" title="">Choose plan</a>		<input type="hidden" name="annualoption" value="<?php print $subacess["annualplan"]; ?>"/>			</form>		</div></div></div><?php if(have_posts()) : while(have_posts()) : the_post(); the_content(); truethemes_link_pages(); endwhile; endif; ?></div><!-- end content --></div><!-- end main-holder --></div><!-- main-area --><?php get_footer(); ?>