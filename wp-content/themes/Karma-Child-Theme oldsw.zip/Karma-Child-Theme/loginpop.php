<div class="modalinner loginpop">
<div class="container headerShort">	
<h3>You must be a SolidWize member to view this video</h3>
</div>
<div id="contact_modal_container" class="container content loginpop">	
<p>Every course on solidwize.com contains free movies that let you assess the 
quality of my tutorials before you subscribe just click on the <span class="blue">blue links</span> to 
watch them. Become a member to access all SolidWize Content.</p>	
<div id="contentpop">

</div>
<div class="loginpop-bottom">
<div class="lg1"><a href="http://solidwize.com/pricing">Become a Member</a></div>
<div class="lg2"><p>Already a member?</p></div>
<div class="lg3"><a href="http://solidwize.com/pricing">Login</a></div>
</div>

</div>
<a href="#" class="close">Close Modal</a>


</div>